<?php

// app root
define('APP_ROOT', dirname(dirname(__FILE__)));

// URL root 
define('URL_ROOT', "http://mxsh-dev.tech/shareposts");

// site name
define('SITE_NAME', "SharePosts");

// app version
define('APP_VERSION', "1.0.0");

// DB PARAMS
define('DB_HOST', 'localhost');
define('DB_USER', 'mxshbqiu_mx');
define('DB_PASSWORD', 'MX971110');
define('DB_NAME', 'mxshbqiu_a2p1');
